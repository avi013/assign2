import React,{Component} from 'react';

class Form extends Component{
    state={
        isLatlongHide:true,
        isCityHide:false,
        inputValue: ''
    }
      handleChange=(e)=>{
        if (e.target.value === "latlong") {
            this.setState({
                isLatlongHide: false,
                isCityHide:true,
            });
       }else if(e.target.value === "zipcode"){
            this.setState({
                isLatlongHide: true,
                isCityHide:false,
            });
        }else{
            this.setState({
                isLatlongHide: true,
                isCityHide:false,
            });
        }
       this.setState({inputValue: e.target.value})
      }
    render(){
        console.log('render of form');
        return(
            <div className="inputData">
            <form id="inputformid" onSubmit={this.props.getWeather}>
                <input typ="text" name="param" className={this.state.isCityHide ? 'hidden' : '' }/>
                <input type="text" name="lat" className={this.state.isLatlongHide ? 'hidden' : '' }/>
                <input type="text" name="long" className={this.state.isLatlongHide ? 'hidden' : ''}/>
                <select name="type" value ={this.state.value} onChange={this.handleChange}>
                    <option value="name">Name</option>
                    <option value="latlong">Lat/Long</option>
                    <option value="zipcode">Zip Code</option>
                </select>
                <button>Get Wether Details</button>
            </form>
        </div>
        );
    }    
}

export default Form;